
# Duo Crisp Chinese Lemon Chicken

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb chicken breasts, cut into strips
- 1/4 cup lemon juice
- 2 tbsp soy sauce
- 1 tbsp honey
- 1/4 cup chicken broth
- 1/4 tsp garlic powder
- Salt and pepper to taste

### Instructions:
1. Add the chicken strips, lemon juice, soy sauce, honey, chicken broth, garlic powder, salt, and pepper to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to lightly crisp the chicken.
5. Serve with rice or noodles.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
