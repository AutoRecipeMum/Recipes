
# Duo Crisp French Croque Monsieur

**Servings**: 3 adult-sized portions

### Ingredients:
- 6 slices of bread
- 1/3 lb ham, thinly sliced
- 1/4 cup grated Gruyère cheese
- 1/4 cup béchamel sauce (store-bought or homemade)
- Butter for spreading

### Instructions:
1. Spread butter on one side of each slice of bread. On the unbuttered side, layer ham, grated cheese, and béchamel sauce.
2. Use the **Air Fryer** function to toast the sandwiches for **6 minutes**, flipping halfway through.
3. Serve immediately with a side salad or chips.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
