
# Duo Crisp Italian Meatball Subs

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb ground beef or turkey
- 1/4 cup breadcrumbs
- 1 egg
- 1/4 cup Parmesan cheese, grated
- 1/4 cup marinara sauce (store-bought)
- 3 sub rolls, sliced
- Salt and pepper to taste

### Instructions:
1. Mix the ground meat, breadcrumbs, egg, Parmesan cheese, salt, and pepper in a bowl to form meatballs.
2. Add the meatballs and marinara sauce to the Instant Pot Duo Crisp.
3. Pressure cook on **Manual/Pressure Cook** mode for **10 minutes**.
4. Perform a **quick release** of the pressure.
5. Switch to the **Air Fryer** function for **3 minutes** to lightly crisp the meatballs.
6. Serve the meatballs in sub rolls with extra marinara sauce.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
