
# Duo Crisp Mexican Quesadillas

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb cooked chicken (leftovers work well)
- 1/4 cup shredded cheese
- 1/4 cup salsa (store-bought)
- 6 small tortillas
- 1/4 cup diced onions (optional, pre-chopped)

### Instructions:
1. Lay tortillas on a flat surface and evenly distribute the cooked chicken, shredded cheese, salsa, and optional diced onions.
2. Fold the tortillas in half.
3. Use the **Air Fryer** function to cook the quesadillas for **5 minutes** at 180°C, flipping halfway through.
4. Serve with extra salsa, guacamole, or sour cream.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
