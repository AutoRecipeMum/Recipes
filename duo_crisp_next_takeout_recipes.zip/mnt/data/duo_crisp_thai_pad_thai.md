
# Duo Crisp Thai Pad Thai

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb shrimp or tofu (pre-cut)
- 1/4 cup pad thai sauce (store-bought)
- 1/4 cup bean sprouts (optional)
- 1/4 cup chopped peanuts (optional)
- 1/4 tsp garlic powder
- 1/4 cup vegetable broth
- Rice noodles (pre-cooked or use quick-cooking variety)

### Instructions:
1. Add the shrimp or tofu, pad thai sauce, garlic powder, and vegetable broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **5 minutes**.
3. Perform a **quick release** of the pressure.
4. Stir in pre-cooked rice noodles and bean sprouts (if using).
5. Use the **Air Fryer** function for **3 minutes** to lightly crisp the dish.
6. Serve with chopped peanuts on top.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
