
# Duo Crisp Chinese Sweet and Sour Chicken

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb chicken thighs, boneless and skinless, cut into pieces
- 1/4 cup canned pineapple chunks with juice
- 1/4 cup bell pepper strips (pre-sliced)
- 1/4 cup sweet and sour sauce (store-bought)
- 1/4 cup vegetable broth
- Salt and pepper to taste

### Instructions:
1. Add the chicken, pineapple chunks, bell pepper strips, sweet and sour sauce, and vegetable broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **10 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for an additional **3 minutes** to lightly crisp the chicken.
5. Serve with rice or noodles.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
