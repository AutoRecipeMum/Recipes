
# Duo Crisp Italian Chicken Alfredo

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb chicken breasts, diced
- 1/2 cup heavy cream
- 1/4 cup Parmesan cheese, grated
- 1 clove garlic, minced (optional)
- 1/2 cup chicken broth
- 1 tbsp butter
- Salt and pepper to taste

### Instructions:
1. Add the diced chicken, heavy cream, Parmesan cheese, garlic, and chicken broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **10 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **3 minutes** to lightly crisp the chicken.
5. Serve over pasta with extra Parmesan cheese.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
