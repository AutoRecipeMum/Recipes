
# Duo Crisp Mexican Burrito Bowl

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb ground beef or turkey
- 1/4 cup black beans (pre-cooked or canned)
- 1/4 cup corn (pre-cooked or canned)
- 1/2 cup diced tomatoes (canned or fresh)
- 1 tsp taco seasoning
- 1/4 cup salsa
- 1/4 cup vegetable broth
- Salt and pepper to taste

### Instructions:
1. Add the ground meat, black beans, corn, diced tomatoes, taco seasoning, salsa, and vegetable broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to reduce liquid and crisp up the meat.
5. Serve over rice with your favorite burrito bowl toppings.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
