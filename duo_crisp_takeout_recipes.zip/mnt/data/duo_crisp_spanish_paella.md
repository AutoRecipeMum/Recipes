
# Duo Crisp Spanish Paella

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb shrimp (peeled and deveined)
- 1/3 cup Arborio rice
- 1/4 cup peas (pre-cooked or frozen)
- 1/4 cup diced tomatoes (canned)
- 1/2 tsp smoked paprika
- 1/2 tsp saffron (optional)
- 1 cup chicken broth
- Salt and pepper to taste

### Instructions:
1. Add the Arborio rice, peas, diced tomatoes, smoked paprika, saffron, chicken broth, salt, and pepper to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Stir in the shrimp and switch to the **Air Fryer** function for **5 minutes** to cook the shrimp and crisp up the paella.
5. Serve warm.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
