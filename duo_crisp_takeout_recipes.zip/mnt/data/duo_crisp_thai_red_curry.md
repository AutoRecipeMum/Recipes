
# Duo Crisp Thai Red Curry

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb firm tofu, cubed (or chicken if preferred)
- 1/2 cup coconut milk
- 1 tbsp red curry paste (store-bought)
- 1/4 cup bell pepper strips (pre-sliced)
- 1/4 cup zucchini slices (optional)
- 1/4 cup vegetable broth
- 1 tsp soy sauce
- Salt and pepper to taste

### Instructions:
1. Add the tofu (or chicken), coconut milk, red curry paste, bell pepper strips, zucchini slices, and vegetable broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Stir in the soy sauce and switch to the **Air Fryer** function for **3 minutes** to lightly roast the vegetables.
5. Serve over rice.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
