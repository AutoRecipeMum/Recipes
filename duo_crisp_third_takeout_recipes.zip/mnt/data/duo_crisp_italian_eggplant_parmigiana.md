
# Duo Crisp Italian Eggplant Parmigiana

**Servings**: 3 adult-sized portions

### Ingredients:
- 1 medium eggplant, sliced
- 1/2 cup marinara sauce (store-bought or homemade)
- 1/4 cup mozzarella cheese, shredded
- 1/4 cup Parmesan cheese, grated
- 1/4 tsp garlic powder
- Salt and pepper to taste

### Instructions:
1. Layer the eggplant slices in the Instant Pot Duo Crisp, adding marinara sauce, mozzarella cheese, Parmesan cheese, garlic powder, salt, and pepper between layers.
2. Pressure cook on **Manual/Pressure Cook** mode for **10 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to crisp the top and melt the cheese.
5. Serve warm with a side salad or bread.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
