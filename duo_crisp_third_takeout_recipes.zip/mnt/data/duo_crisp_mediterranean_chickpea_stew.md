
# Duo Crisp Mediterranean Chickpea Stew

**Servings**: 3 adult-sized portions

### Ingredients:
- 1 can chickpeas, drained and rinsed
- 1/4 cup diced tomatoes (canned)
- 1/2 cup vegetable broth
- 1/4 cup zucchini slices (optional)
- 1/4 tsp cumin
- 1/4 tsp paprika
- 1/4 tsp garlic powder
- Salt and pepper to taste

### Instructions:
1. Add the chickpeas, diced tomatoes, vegetable broth, zucchini slices, cumin, paprika, garlic powder, salt, and pepper to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **10 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to reduce the liquid and thicken the stew.
5. Serve warm with bread or rice.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
