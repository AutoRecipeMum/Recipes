
# Duo Crisp Portuguese Chicken and Rice

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb chicken thighs, boneless and skinless, diced
- 1/3 cup Arborio rice
- 1/4 cup diced tomatoes (canned or fresh)
- 1/4 cup green peas (pre-cooked or frozen)
- 1/2 tsp paprika
- 1/2 tsp garlic powder
- 1 cup chicken broth
- Salt and pepper to taste

### Instructions:
1. Add the chicken, rice, tomatoes, green peas, paprika, garlic powder, and chicken broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **12 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to lightly crisp the rice and chicken.
5. Serve warm.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
