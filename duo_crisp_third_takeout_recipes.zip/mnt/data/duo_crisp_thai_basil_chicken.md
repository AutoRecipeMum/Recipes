
# Duo Crisp Thai Basil Chicken

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb chicken breasts, diced
- 1 tbsp soy sauce
- 1 tbsp fish sauce
- 1 tbsp oyster sauce
- 1/2 cup bell pepper strips (pre-sliced)
- 1 clove garlic, minced (optional)
- 1/4 cup chicken broth
- Fresh basil leaves (optional)

### Instructions:
1. Add the chicken, soy sauce, fish sauce, oyster sauce, bell pepper strips, garlic (if using), and chicken broth to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **3 minutes** to lightly crisp the chicken.
5. Serve with rice and fresh basil leaves on top.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
