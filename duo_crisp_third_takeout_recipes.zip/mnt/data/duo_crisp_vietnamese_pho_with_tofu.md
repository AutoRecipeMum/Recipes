
# Duo Crisp Vietnamese Pho with Tofu

**Servings**: 3 adult-sized portions

### Ingredients:
- 1/3 lb firm tofu, cubed
- 1/4 cup soy sauce
- 1/2 cup vegetable broth
- 1/2 tsp five-spice powder (optional)
- 1 clove garlic, minced (optional)
- Pre-cooked rice noodles (optional)
- Fresh cilantro and lime wedges for serving

### Instructions:
1. Add the tofu, soy sauce, vegetable broth, five-spice powder, and garlic to the Instant Pot Duo Crisp.
2. Pressure cook on **Manual/Pressure Cook** mode for **8 minutes**.
3. Perform a **quick release** of the pressure.
4. Switch to the **Air Fryer** function for **5 minutes** to lightly crisp the tofu.
5. Serve the tofu over pre-cooked rice noodles with fresh cilantro and lime wedges.

### Storage Instructions:
- Store leftovers in an airtight container in the fridge for up to 2 days.
